<div id="booking-route-passenger">
    <h4 class="mb-0">Passengers</h4>
    <small>Enter passenger detail</mall>
    <div class="row mt-2 mb-5 border-radius-10 border border-booking-passenger">
        <div class="col-12 py-3 bg-booking-passenger" style="border-radius: 10px 10px 0 0;">
            Passenger 1 <span class="text-light">(Lead passenger)</span>
        </div>
        <div class="col-12 mt-3" id="lead-passenger">
            <div class="row">
                <div class="col-2 form-floating mb-3">
                    <select required class="form-select form-select-sm" name="title[]" id="passenger-title" aria-label="Floating label select example">
                        <option value="" selected disabled>Select Title</option>
                        <option value="mr">Mr.</option>
                        <option value="mrs">Mrs.</option>
                        <option value="ms">Ms.</option>
                        <option value="other">Other</option>
                    </select>
                    <label for="passenger-title">Title<span class="text-danger">*</span></label>
                </div>
                <div class="col-5 form-floating mb-3">
                    <input required type="text" class="form-control form-control-sm" name="first_name[]" id="passenger-first-name" placeholder="First name & Middle name">
                    <label for="passenger-first-name" class="ms-2">First name & Middle name<span class="text-danger">*</span></label>
                </div>
                <div class="col-5 form-floating mb-3">
                    <input required type="text" class="form-control form-control-sm" name="last_name[]" id="passenger-last-name" placeholder="Last name">
                    <label for="passenger-last-name" class="ms-2">Last name<span class="text-danger">*</span></label>
                </div>
            </div>
            <div class="row">
                <div class="col-7 form-floating mb-3">
                    <input required type="text" name="birth_day[]" class="form-control form-control-sm datepicker"
                        data-show-weeks="true"
                        data-today-highlight="true"
                        data-today-btn="false"
                        data-clear-btn="false"
                        data-autoclose="true"
                        data-format="DD/MM/YYYY"
                        autocomplete="off"
                        placeholder="Birth Day date">
                    <label class="ms-2">Birth Day date<span class="text-danger">*</span></label>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-7">
                    <label class="form-label">Contact Infomation</label>
                    <div class="form-floating mb-3">
                        <input required type="email" name="email" class="form-control form-control-sm" id="passenger-email" placeholder="E-mail" autocomplete="true">
                        <label for="passenger-email" class="ms-2">E-mail<span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="col-5">
                    <label class="form-label">Telephone number<span class="text-danger">*</span></label>
                    <div class="row">
                        <div class="col-4">
                            <select required class="form-select" name="mobile_code">
                                <option value="" selected disabled></option>
                                <?php $__currentLoopData = $code_country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($code); ?>">+<?php echo e($code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-8">
                            <input required type="number" class="form-control" name="mobile">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-7">
                    <div class="form-floating mb-3">
                        <input required type="email" name="confirm_email" class="form-control form-control-sm" id="passenger-confirm-email" placeholder="Confirm E-mail">
                        <label for="passenger-confirm-email" class="ms-2">Confirm E-mail<span class="text-danger">*</span></label>
                    </div>
                </div>
                <div class="col-5 position-relative">
                    <label class="form-label position-absolute mt-n4">Thai telephone number (if any)</label>
                    <div class="row">
                        <div class="col-4">
                            <input type="text" name="th_code" class="form-control" value="+66" readonly>
                        </div>
                        <div class="col-8">
                            <input type="number" name="th_mobile" class="form-control">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-5 form-floating mb-3">
                    <select required class="form-select form-select-sm" name="country" id="passenger-country" aria-label="Floating label select example" autocomplete="true">
                        <option value="" selected disabled>Select Country</option>
                        <?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country); ?>"><?php echo e($country); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="passenger-country">Country<span class="text-danger">*</span></label>
                </div>
                <div class="col-5 offset-2 form-floating mb-3">
                    <input type="number" name="passport_number" class="form-control form-control-sm" id="passenger-passport" placeholder="Passport Number">
                    <label for="passenger-passport" class="ms-2">Passport Number</label>
                </div>
            </div>
            <div class="row">
                <div class="col-12 form-floating mb-3">
                    <textarea class="form-control" placeholder="Address" id="passenger-address" name="address" style="height: 100px" autocomplete="true"></textarea>
                    <label for="passenger-address" class="ms-2">Address</label>
                </div>
            </div>
        </div>
        <input type="hidden" name="passenger_type[]" value="Adult">
    </div>

    <?php
        $is_passenger = 2;
    ?>

    <?php if($passenger[0] > 1): ?>
        <?php for($i = $is_passenger; $i <= $passenger[0]; $i++): ?>
            <?php if (isset($component)) { $__componentOriginal6977ce3112e673bfbf4d43d524afdfde = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.set-passenger','data' => ['passengerNum' => $is_passenger,'type' => _('Adult'),'color' => _('booking-passenger')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('set-passenger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['passenger_num' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($is_passenger),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Adult')),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('booking-passenger'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6977ce3112e673bfbf4d43d524afdfde)): ?>
<?php $component = $__componentOriginal6977ce3112e673bfbf4d43d524afdfde; ?>
<?php unset($__componentOriginal6977ce3112e673bfbf4d43d524afdfde); ?>
<?php endif; ?>
            <?php
                $is_passenger++;
            ?>
        <?php endfor; ?>
    <?php endif; ?>

    <?php if($passenger[1] > 0): ?>
        <?php for($i = 1; $i <= $passenger[1]; $i++): ?>
            <?php if (isset($component)) { $__componentOriginal6977ce3112e673bfbf4d43d524afdfde = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.set-passenger','data' => ['passengerNum' => $is_passenger,'type' => _('Child'),'color' => _('booking-passenger')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('set-passenger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['passenger_num' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($is_passenger),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Child')),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('booking-passenger'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6977ce3112e673bfbf4d43d524afdfde)): ?>
<?php $component = $__componentOriginal6977ce3112e673bfbf4d43d524afdfde; ?>
<?php unset($__componentOriginal6977ce3112e673bfbf4d43d524afdfde); ?>
<?php endif; ?>
            <?php
                $is_passenger++;
            ?>
        <?php endfor; ?>
    <?php endif; ?>

    <?php if($passenger[2] > 0): ?>
        <?php for($i = 1; $i <= $passenger[2]; $i++): ?>
            <?php if (isset($component)) { $__componentOriginal6977ce3112e673bfbf4d43d524afdfde = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.set-passenger','data' => ['passengerNum' => $is_passenger,'type' => _('Infant'),'color' => _('booking-passenger')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('set-passenger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['passenger_num' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($is_passenger),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Infant')),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('booking-passenger'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6977ce3112e673bfbf4d43d524afdfde)): ?>
<?php $component = $__componentOriginal6977ce3112e673bfbf4d43d524afdfde; ?>
<?php unset($__componentOriginal6977ce3112e673bfbf4d43d524afdfde); ?>
<?php endif; ?>
            <?php
                $is_passenger++;
            ?>
        <?php endfor; ?>
    <?php endif; ?>
</div><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/booking/one-way-trip/booking-passenger.blade.php ENDPATH**/ ?>