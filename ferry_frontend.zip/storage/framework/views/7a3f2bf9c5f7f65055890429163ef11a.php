<?php $__env->startSection('cover-content'); ?>
    <?php if($isType != ''): ?>
    <div class="px-3 py-2 bg-booking-cover lazy text-light">
        <div class="row">
            <div class="col-1 d-flex align-items-center justify-content-end">
                <i class="fa-solid fa-ship fs-1"></i>
            </div>
            <div class="col-7 d-flex align-items-center">
                <p class="mb-1"><?php echo e($is_station['from']); ?>

                <span class="mx-2">To</span>
                <?php echo e($is_station['to']); ?> <span class="ms-2"><?php echo e($booking_date); ?></span> <span class="ms-2 set-time-route-select"></span></p>
            </div>
            <div class="col-2 py-2 border-start d-flex align-items-center justify-content-center">
                <a tabindex="0" class="btn btm-sm btn-link text-light popover-passenger" role="button" 
                    data-bs-toggle="popover" data-bs-placement="bottom" data-bs-trigger="focus" data-bs-html="true" 
                    data-bs-content="<strong>Adult :</strong> <?php echo e($passenger[0]); ?> | <strong>Child :</strong> <?php echo e($passenger[1]); ?> | <strong>Infant :</strong> <?php echo e($passenger[2]); ?>">
                    <i class="fi fi-users me-2"></i> Passenger <i class="fi fi-arrow-down ms-1"></i>
                </a>
                <?php if($passenger[0] != 0): ?>
                    <input type="hidden" id="passenger-adult" value="<?php echo e($passenger[0]); ?>" disabled>
                <?php endif; ?>
                <?php if($passenger[1] != 0): ?>
                    <input type="hidden" id="passenger-child" value="<?php echo e($passenger[1]); ?>" disabled>
                <?php endif; ?>
                <?php if($passenger[2] != 0): ?>
                    <input type="hidden" id="passenger-infant" value="<?php echo e($passenger[2]); ?>" disabled>
                <?php endif; ?>
            </div>
            <div class="col-2 border-start d-flex align-items-center justify-content-center">
                THB <span class="ms-2" id="sum-price">0.00</span>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ol class="process-steps process-steps-primary text-muted mb-3">
	<li class="process-step-item complete" data-step="booking"><span class="ps-3"><?php echo e($isType != '' ? $isType : 'Booking'); ?></span></li>
	<li class="process-step-item text-primary active" data-step="select"><span class="ps-3">Select</span></li>
	<li class="process-step-item" data-step="passenger"><span class="ps-3">Passenger info</span></li>
    <li class="process-step-item" data-step="extra"><span class="ps-3">Extra services</span></li>
    <li class="process-step-item" data-step="payment"><span class="ps-3">Payment</span></li>
</ol>

<div class="row">
    <div class="col-12">
        <?php if($isType != ''): ?>
        <form novalidate class="bs-validate" id="booking-form" method="POST" action="<?php echo e(route('booking-confirm')); ?>">
            <?php echo csrf_field(); ?>
            <div class="procress-step d-none"></div>
            <div class="procress-step d-none">
                <!-- booking select -->
                <?php echo $__env->make('pages.booking.one-way-trip.booking-select', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="procress-step d-none">
                <!-- booking passenger -->
                <?php echo $__env->make('pages.booking.one-way-trip.booking-passenger', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="procress-step d-none">
                <!-- booking extra -->
                <?php echo $__env->make('pages.booking.one-way-trip.booking-extra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="procress-step d-none">
                <!-- booking payment -->
                <?php echo $__env->make('pages.booking.one-way-trip.booking-payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="row mt-3">
                <div class="col-6">
                    <button type="button" class="btn btn-sm btn-secondary border-radius-10" id="progress-prev" disabled><< Back</button>
                </div>
                <div class="col-6 text-end">
                    <?php if (isset($component)) { $__componentOriginal881613893964646b4dfce1bd118c0fef = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-green','data' => ['id' => 'progress-next','class' => 'btn-sm','type' => _('button'),'text' => _('Continue >>'),'disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-green'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'progress-next','class' => 'btn-sm','type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('button')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Continue >>')),'disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal881613893964646b4dfce1bd118c0fef)): ?>
<?php $component = $__componentOriginal881613893964646b4dfce1bd118c0fef; ?>
<?php unset($__componentOriginal881613893964646b4dfce1bd118c0fef); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal881613893964646b4dfce1bd118c0fef = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-green','data' => ['id' => 'progress-next-passenger','class' => 'btn-sm d-none','type' => _('button'),'text' => _('Continue >>'),'onClick' => 'progressPassenger()','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-green'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'progress-next-passenger','class' => 'btn-sm d-none','type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('button')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Continue >>')),'onClick' => 'progressPassenger()','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal881613893964646b4dfce1bd118c0fef)): ?>
<?php $component = $__componentOriginal881613893964646b4dfce1bd118c0fef; ?>
<?php unset($__componentOriginal881613893964646b4dfce1bd118c0fef); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal881613893964646b4dfce1bd118c0fef = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-green','data' => ['id' => 'progress-payment','class' => 'btn-sm d-none','type' => _('submit'),'text' => _('Book / Payment'),'disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-green'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'progress-payment','class' => 'btn-sm d-none','type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('submit')),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('Book / Payment')),'disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal881613893964646b4dfce1bd118c0fef)): ?>
<?php $component = $__componentOriginal881613893964646b4dfce1bd118c0fef; ?>
<?php unset($__componentOriginal881613893964646b4dfce1bd118c0fef); ?>
<?php endif; ?>
                </div>
            </div>
        </form>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    let isStep = <?php echo e($isType == '' ? 0 : 1); ?>

</script>
<script src="<?php echo e(asset('assets/js/app/progress_bar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/booking/one-way-trip/index.blade.php ENDPATH**/ ?>