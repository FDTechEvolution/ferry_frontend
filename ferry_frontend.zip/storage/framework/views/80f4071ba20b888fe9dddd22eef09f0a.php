<div id="booking-multi-route-select">
    <?php $__currentLoopData = $route_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $routes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mb-4">
        <div class="col-12 mb-2">
            <p class="mb-0 fw-bolder">
                <span class="me-0">Depart : </span>
                <span class="station-name depart-station-name-<?php echo e($index); ?> me-4"><?php echo e($routes['station_from']); ?></span>
                <span class="me-0">Arrival : </span>
                <span class="station-name arrive-station-name-<?php echo e($index); ?> me-4"><?php echo e($routes['station_to']); ?></span>
                <span class="me-0">Date : </span>
                <span class="station-name travel-date-<?php echo e($index); ?>"><?php echo e($routes['depart']); ?></span>
            </p>
        </div>
        <div class="col-11 ms-5 booking-route-select">
            <?php $__currentLoopData = $routes['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row p-2 px-4 mb-4 border rounded booking-route-list route-hover cursor-pointer list-index_<?php echo e($index); ?> list-position_<?php echo e($index); ?>_<?php echo e($key); ?>" data-list="<?php echo e($index); ?>" data-key="<?php echo e($key); ?>">
                    <div class="col-12 pb-2 border-0 border-bottom border-2 border-light">
                        <div class="float-start">
                            <span class="me-2">Depart</span>
                            <span class="station-name me-4"><?php echo e($route['station_from']['name']); ?> <?php if($route['station_from']['piername'] != NULL): ?> (<?php echo e($route['station_from']['piername']); ?>) <?php endif; ?></span>
                            <span class="me-2">Arrival</span>
                            <span class="station-name"><?php echo e($route['station_to']['name']); ?> <?php if($route['station_to']['piername'] != NULL): ?> (<?php echo e($route['station_to']['piername']); ?>) <?php endif; ?></span>
                        </div>
                        <div class="float-end">
                            <span class="px-3">Fare</span>
                        </div>
                    </div>

                    <div class="col-12 py-3 border-0 border-bottom border-2 border-light">
                        <div class="float-start d-flex align-items-center">
                            <span class="me-2 depart-time"><?php echo e(date("H:i", strtotime($route['depart_time']))); ?></span>
                            <span class="me-2">
                                <svg width="18px" height="18px" xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">  
                                    <path fill-rule="evenodd" d="M3.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L9.293 8 3.646 2.354a.5.5 0 0 1 0-.708z"></path>  
                                    <path fill-rule="evenodd" d="M7.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L13.293 8 7.646 2.354a.5.5 0 0 1 0-.708z"></path>
                                </svg>
                            </span>
                            <div class="d-flex me-2">
                                <?php $__currentLoopData = $route['icons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mw--48">
                                    <img src="<?php echo e($icon_url); ?><?php echo e($icon['path']); ?>" class="me-1 w-100 icon-selected">
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <span class="me-2">
                                <svg width="18px" height="18px" xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">  
                                    <path fill-rule="evenodd" d="M3.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L9.293 8 3.646 2.354a.5.5 0 0 1 0-.708z"></path>  
                                    <path fill-rule="evenodd" d="M7.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L13.293 8 7.646 2.354a.5.5 0 0 1 0-.708z"></path>
                                </svg>
                            </span>
                            <span class="me-2 arrival-time"><?php echo e(date("H:i", strtotime($route['arrive_time']))); ?></span>
                        </div>
                        <div class="float-end d-flex align-items-center">
                            <span class="bg-white py-1 px-3 rounded border border-warning route-price"><?php echo e(number_format($route['p_adult'] + $route['p_child'] + $route['p_infant'])); ?></span>
                        </div>
                    </div>
                    <input type="hidden" class="selected-adult-price" value="<?php echo e($route['regular_price']); ?>">
                    <input type="hidden" class="selected-child-price" value="<?php echo e($route['child_price']); ?>">
                    <input type="hidden" class="selected-infant-price" value="<?php echo e($route['infant_price']); ?>">
                    <input type="hidden" class="selected-route-<?php echo e($index); ?>_<?php echo e($key); ?>" value="<?php echo e($route['id']); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <input type="hidden" name="booking_route_selected[<?php echo e($index); ?>]" id="booking-route-selected" value="">
    <input type="hidden" name="departdate[<?php echo e($index); ?>]" id="booking-route-departdate" value="">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/booking/multi-island/booking-select.blade.php ENDPATH**/ ?>