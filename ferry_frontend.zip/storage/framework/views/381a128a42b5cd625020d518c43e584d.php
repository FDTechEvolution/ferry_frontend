<a class="navbar-brand" href="<?php echo e(route('home')); ?>">
    <img src="<?php echo e(asset('tiger-line-ferry_logo.png')); ?>" alt="andamanexpress" style="margin-top: -10px;">
</a><?php /**PATH D:\Work\ferry_frontend\resources\views/includes/logo.blade.php ENDPATH**/ ?>