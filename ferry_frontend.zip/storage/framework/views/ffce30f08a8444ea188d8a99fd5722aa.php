<!doctype html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</head>
    <body>
		<div id="wrapper">
			<!-- Header -->
			<header id="header" class="shadow-xs">
				<!-- Navbar -->
                <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /Navbar -->
            </header>
            <!-- /Header -->

            <!-- COVER -->
            <?php echo $__env->yieldContent('cover-content'); ?>
			<!-- /COVER -->

            <div class="section pb-2 pt-5">
				<div class="container">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

            <?php echo $__env->yieldContent('section-content'); ?>
        </div>

        <!-- Footer -->
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /Footer -->

        <script src="<?php echo e(asset('assets/js/core.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/app/app.js')); ?>"></script>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html><?php /**PATH D:\Work\ferry_frontend\resources\views/layouts/default.blade.php ENDPATH**/ ?>