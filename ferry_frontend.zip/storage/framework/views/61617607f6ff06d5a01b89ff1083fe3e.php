<?php $__env->startSection('head_meta'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cover-content'); ?>
<div class="px-3 py-2 bg-primary lazy text-light">
    <div class="row">
        <div class="col-9 offset-1 d-flex align-items-center">
            <h4 class="my-2" style="line-height: 20px;">View your booking<br/>
                <span class="smaller mb-0" id="booking-number"><?php echo e($booking['booking_number']); ?></span>
            </h4>
        </div>
        <div class="col-2 text-center">
            <p class="mb-1">status</p>
            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'bg-light',
                'px-4',
                'py-1',
                'fw-bold',
                'rounded',
                'text-second-color' => $booking['status'] == 'CO',
                'text-main-color-2' => $booking['status'] == 'DR',
                'text-secondary' => $booking['status'] == 'VO'
            ]); ?>"><?php echo e($booking_status[$booking['status']]); ?></span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if($booking['do_update']): ?>
        <?php if($booking['ispayment'] == 'N'): ?>
        <div class="col-12 text-center mb-3">
            <form method="POST" action="<?php echo e(route('payment-link')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="booking_number" value="<?php echo e($booking['booking_number']); ?>">
                <button type="submit" class="btn button-green-bg rounded px-5 py-2">Payment</button>
            </form>
        </div>
        <?php elseif($booking['ispayment'] == 'Y'): ?>
        <div class="col-12 text-center mb-3">
            <a href="<?php echo e(route('payment-print', ['bookingno' => $booking['booking_number']])); ?>" class="btn button-blue-bg rounded px-5 py-2" target="_blank">Print Bill</a>
        </div>
        <?php endif; ?>
    <?php endif; ?>
    <div class="col-12">
        <h4 class="mb-0 fw-bold">Passenger(s)</h4>
        <p class="mb-2">Passenger detail</p>
        <div class="row bg-booking-payment-passenger mx-3 p-4 mb-5">
            <div class="col-12">
                <div class="row" id="payment-passenger-detail">
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key === 'ADULT'): ?>
                            <h6 class="fw-bold mb-1">Adult</h6>
                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex">
                                    <p class="ms-3"><?php echo e($cus['name']); ?></p>
                                    <p class="ms-3"><strong class="fw-bold">Date of birth :</strong> xxxx</p>
                                    <?php if($cus['email'] != null): ?>
                                        <p class="ms-3"><strong class="fw-bold">Email :</strong> <?php echo e($cus['email']); ?> <span class="badge bg-primary-soft">Lead passenger</span></p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key === 'CHILD'): ?>
                            <h6 class="fw-bold mb-1">Child</h6>
                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex">
                                    <p class="ms-3"><?php echo e($cus['name']); ?></p>
                                    <p class="ms-3"><strong class="fw-bold">Date of birth :</strong> xxxx</p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key === 'INFANT'): ?>
                            <h6 class="fw-bold mb-1">Infan</h6>
                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex">
                                    <p class="ms-3"><?php echo e($cus['name']); ?></p>
                                    <p class="ms-3"><strong class="fw-bold">Date of birth :</strong> xxxx</p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <h4 class="mb-0 fw-bold">Booking</h4>
        <p class="mb-2">Detail</p>
        <div class="row bg-booking-payment-passenger mx-3 p-4 mb-5">
            <div class="col-12">
                <div class="row" id="payment-passenger-detail">
                    <?php $__currentLoopData = $booking['route']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3">
                            <h6 class="fw-bold mb-1">From</h6>
                            <p class="mb-1">
                                <?php echo e($route['station_from']); ?>

                                <?php if($route['station_from_pier'] != null): ?> (<?php echo e($route['station_from_pier']); ?>) <?php endif; ?>
                                <?php if($route['station_from_nickname'] != null): ?> [<?php echo e($route['station_from_nickname']); ?>] <?php endif; ?>
                            </p>
                            <div style="line-height: 15px;">
                                <p class="small mb-1"><?php echo e(date_format(date_create($booking['depart_date']), 'd/m/Y')); ?></p>
                                <p class="small mb-0"><?php echo e(date_format(date_create($route['depart_time']), 'H:i')); ?></p>
                            </div>
                        </div>
                        <div class="col-3">
                            <h6 class="fw-bold mb-1">To</h6>
                            <p class="mb-1">
                                <?php echo e($route['station_to']); ?> 
                                <?php if($route['station_to_pier'] != null): ?> (<?php echo e($route['station_to_pier']); ?>) <?php endif; ?>
                                <?php if($route['station_to_nickname'] != null): ?> [<?php echo e($route['station_to_nickname']); ?>] <?php endif; ?>
                            </p>
                            <div style="line-height: 15px;">
                                <p class="small mb-1"><?php echo e(date_format(date_create($booking['depart_date']), 'd/m/Y')); ?></p>
                                <p class="small mb-0"><?php echo e(date_format(date_create($route['arrive_time']), 'H:i')); ?></p>
                            </div>
                        </div>
                        <div class="col-3 text-center">
                            <h6 class="fw-bold mb-1">Passenger</h6>
                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mb-1"><?php echo e($cus['name']); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($booking['do_update']): ?>
                                <button class="btn btn-sm button-orange-bg rounded py-1 mt-1" data-bs-toggle="modal" data-bs-target="#add-person">Add person</button>
                                <form method="POST" id="form-confirm-merge" action="<?php echo e(route('booking-record')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="booking_number" id="booking-number-current" value="<?php echo e($booking['booking_number']); ?>">
                                    <input type="hidden" name="booking_number_new" id="booking-number-new" value="">
                                </form>
                            <?php endif; ?>
                        </div>
                        <div class="col-3 text-center">
                            <h6 class="fw-bold mb-1">Extra detail</h6>
                            <?php $__currentLoopData = $booking['extra']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mb-0 small"><?php echo e($extra['name']); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($booking['do_update']): ?>
                        <div class="col-12 text-end mt-3">
                            <button class="btn btn-sm button-orange-bg rounded py-1 px-5">Edit</button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if($booking['do_update']): ?>
        <div class="row bg-booking-payment-passenger mx-3 p-4 mb-5">
            <div class="col-12">
                <h4 class="mb-0 fw-bold">Add Multiple Trip</h4>
                <div class="row px-3 mt-2">
                    <div class="col-3">
                        <div class="form-floating mb-3">
                            <select required class="form-select form-select-sm" name="from[]" id="form-select" aria-label="booking station">
                                <option value="" selected>Select Original</option>
                                <option value="<?php echo e($station_from[0]['station_to_id']); ?>"><?php echo e($route['station_to']); ?> <?php if($route['station_to_pier'] != null): ?> (<?php echo e($route['station_to_pier']); ?>) <?php endif; ?></option>
                            </select>
                            <label for="form-select">From</label>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-floating mb-3">
                            <select required class="form-select form-select-sm" name="to[]" id="to-select" aria-label="booking station">
                                <option value="" selected disabled>Select Destination</option>
                                <?php $__currentLoopData = $station_to; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($station['id']); ?>"><?php echo e($station['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="to-select">To</label>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-floating mb-3">
                            <input required type="text" name="depart_date[]" class="form-control form-control-sm datepicker"
                                data-show-weeks="true"
                                data-today-highlight="true"
                                data-today-btn="true"
                                data-clear-btn="false"
                                data-autoclose="true"
                                data-date-start="today"
                                data-format="DD/MM/YYYY"
                                autocomplete="off"
                                placeholder="Departure date">
                            <label class="text-secondary">Departure date</label>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-floating mb-3">
                            <input required type="text" name="return_date[]" class="form-control form-control-sm datepicker"
                                data-show-weeks="true"
                                data-today-highlight="true"
                                data-today-btn="true"
                                data-clear-btn="false"
                                data-autoclose="true"
                                data-date-start="today"
                                data-format="DD/MM/YYYY"
                                autocomplete="off"
                                placeholder="Return date">
                            <label class="text-secondary">Return date</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <h4 class="mb-0 fw-bold">Extra Services</h4>
        <p class="mb-2">please select youradditional services</p>
        <div class="row mx-3 mb-5">
            <div class="col-4">
                <div class="card">
                    <img src="<?php echo e(asset('pad-thai_addon.jpg')); ?>" class="card-img-top" alt="meal" style="min-height: 240px; max-height: 240px;">
                    <div class="card-body bg-booking-payment-extra">
                        <h5 class="card-title">Meal</h5>
                        <p class="card-text">Keep up your energy level with reserved meals and beverages.</p>
                        <?php if($booking['do_update']): ?>
                            <div class="text-center mt-2">
                                <button class="btn btn-sm button-orange-bg rounded py-1 mt-1" <?php if(empty($addons['meals'])): ?> disabled <?php endif; ?> data-bs-toggle="modal" data-bs-target="#extra-services">Select</button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card">
                    <img src="<?php echo e(asset('cover/cover_03.webp')); ?>" class="card-img-top" alt="activity" style="min-height: 240px; max-height: 240px;">
                    <div class="card-body bg-booking-payment-extra">
                        <h5 class="card-title">Daytrip</h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <?php if($booking['do_update']): ?>
                            <div class="text-center mt-2">
                                <button class="btn btn-sm button-orange-bg rounded py-1 mt-1" <?php if(empty($addons['activities'])): ?> disabled <?php endif; ?>>Select</button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if($booking['do_update']): ?>
        <div class="row bg-warning-soft mx-3 p-4 mb-5">
            <div class="col-12">
                <h4 class="mb-1 text-dark fw-bold">Contact Services</h4>
                <textarea class="form-control" rows="6"></textarea>
            </div>
        </div>

        <div class="row mb-5">
            <div class="col-12 text-end">
                <button class="btn btn-sm button-green-bg">Update</button>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo $__env->make('pages.payment.modal_extraservice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.payment.modal_addperson', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    const booking_current = `<?php echo e($booking['booking_number']); ?>`
</script>
<script src="<?php echo e(asset('assets/js/app/payment.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/booking/view.blade.php ENDPATH**/ ?>