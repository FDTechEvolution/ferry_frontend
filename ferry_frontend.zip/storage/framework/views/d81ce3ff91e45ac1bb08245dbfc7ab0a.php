<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type' => '', 'station_from' => [], 'station_to' => [], 'form_type' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => '', 'station_from' => [], 'station_to' => [], 'form_type' => '']); ?>
<?php foreach (array_filter((['type' => '', 'station_from' => [], 'station_to' => [], 'form_type' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $from_id = uniqid();
    $to_id = uniqid();
    $date_id = uniqid();
    $passenger_id = uniqid();
?>

<div class="row px-3 is-type-<?php echo e($form_type); ?>">
    <input type="hidden" name="_from_type[]" value="<?php echo e($form_type); ?>">
    <div class="col-sm-3 col-md-3 px-0">
        <div class="form-floating mb-3">
            <select required class="form-select form-select-sm from-<?php echo e($type); ?>-<?php echo e($form_type); ?>-selected" name="from[]" id="from-<?php echo e($from_id); ?>" aria-label="booking station" onChange="fromOriginalSelected(this, '<?php echo e($type); ?>', '<?php echo e($form_type); ?>')">
                <option value="" selected disabled>Select Original</option>
                <?php $__currentLoopData = $station_from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_key => $sections): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($section_key); ?>">
                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($station['id']); ?>"><?php echo e($station['name']); ?> <?php if($station['piername'] != NULL): ?> (<?php echo e($station['piername']); ?>) <?php endif; ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="from-<?php echo e($from_id); ?>">From</label>
        </div>
    </div>
    <div class="col-sm-3 col-md-3 px-0">
        <div class="form-floating mb-3">
            <select required class="form-select form-select-sm to-<?php echo e($type); ?>-<?php echo e($form_type); ?>-selected" name="to[]" id="to-<?php echo e($to_id); ?>" aria-label="booking station" disabled>
                <option value="" selected>Select Destination</option>
                <?php $__currentLoopData = $station_to; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_key => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($section_key); ?>">
                        <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($station['id']); ?>"><?php echo e($station['name']); ?> <?php if($station['piername'] != NULL): ?> (<?php echo e($station['piername']); ?>) <?php endif; ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="to-<?php echo e($to_id); ?>">To</label>
        </div>
    </div>
    <div class="col-sm-3 col-md-3 px-0">
        <?php if($form_type == 'depart'): ?>
            <div class="form-floating mb-3">
                <input required type="text" name="date[]" class="form-control form-control-sm datepicker date-<?php echo e($type); ?>-<?php echo e($form_type); ?>-selected"
                    data-show-weeks="true"
                    data-today-highlight="true"
                    data-today-btn="true"
                    data-clear-btn="false"
                    data-autoclose="true"
                    data-date-start="today"
                    data-format="DD/MM/YYYY"
                    autocomplete="off"
                    placeholder="Travel Date">
                <label class="text-secondary">Travel Date</label>
            </div>
        <?php else: ?>
            <div class="form-floating mb-3">
                <input required autocomplete="off" type="text" name="date[]" class="form-control rangepicker"
                    data-bs-placement="left"
                    data-ranges="false"
                    data-disable-past-dates="true"
                    data-date-start="<?php echo e(date('d/m/Y', strtotime('+1 day'))); ?>"
                    data-date-end="<?php echo e(date('d/m/Y', strtotime('+2 day'))); ?>"
                    data-date-format="DD/MM/YYYY"
                    data-quick-locale='{
                        "lang_apply"	: "Apply",
                        "lang_cancel" : "Cancel",
                        "lang_crange" : "Custom Range",
                        "lang_months"	 : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                        "lang_weekdays" : ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
                    }'
                    placeholder="Depart date - Return date">
                <label class="text-secondary">Depart date - Return date</label>
            </div>
        <?php endif; ?>
    </div>
    <div class="col-sm-3 col-md-3 px-0">
        <div class="form-floating mb-3 dropdown">
            <input required type="text" class="dropdown-toggle form-control" data-id="<?php echo e($type); ?><?php echo e($form_type); ?>" id="pass-<?php echo e($passenger_id); ?>" data-bs-toggle="dropdown" placeholder="Passenger">
            <label class="text-secondary" for="pass-<?php echo e($passenger_id); ?>">Passenger</label>
        
            <div class="dropdown-menu dropdown-click-ignore dropdown-md p-3">
                <div class="row mb-2 border-bottom">
                    <div class="col-md-6 lh-1">
                        <p class="text-primary mb-0">Adult</p>
                        <small class="smaller">Above 12 year old</small>
                    </div>
                    <div class="col-md-2 p-0 text-end">
                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-2" data-type="adult" onClick="dec('<?php echo e($type); ?><?php echo e($form_type); ?>_adult[]', this)"><i class="fi fi-minus smaller"></i></button>
                    </div>
                    <div class="col-md-2 p-0 text-center">
                        <input required type="number" class="border-0 text-center w-100" name="<?php echo e($type); ?><?php echo e($form_type); ?>_adult[]" value="0">
                    </div>
                    <div class="col-md-2 p-0">
                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-2" data-type="adult" onClick="inc('<?php echo e($type); ?><?php echo e($form_type); ?>_adult[]', this)"><i class="fi fi-plus smaller"></i></button>
                    </div>
                </div>

                <div class="row mb-2 border-bottom">
                    <div class="col-md-6 lh-1">
                        <p class="text-primary mb-0">Child</p>
                        <small class="smaller">2 - 12 year old</small>
                    </div>
                    <div class="col-md-2 p-0 text-end">
                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-2" data-type="child" onClick="dec('<?php echo e($type); ?><?php echo e($form_type); ?>_child[]', this)"><i class="fi fi-minus smaller"></i></button>
                    </div>
                    <div class="col-md-2 p-0 text-center">
                        <input type="number" class="border-0 text-center w-100" name="<?php echo e($type); ?><?php echo e($form_type); ?>_child[]" value="0">
                    </div>
                    <div class="col-md-2 p-0">
                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-2" data-type="child" data-inc="disabled" onClick="inc('<?php echo e($type); ?><?php echo e($form_type); ?>_child[]', this)" disabled><i class="fi fi-plus smaller"></i></button>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 lh-1">
                        <p class="text-primary mb-0">Infant</p>
                        <small class="smaller">Below 2 year old</small>
                    </div>
                    <div class="col-md-2 p-0 text-end">
                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-2" data-type="infant" onClick="dec('<?php echo e($type); ?><?php echo e($form_type); ?>_infant[]', this)"><i class="fi fi-minus smaller"></i></button>
                    </div>
                    <div class="col-md-2 p-0 text-center">
                        <input type="number" class="border-0 text-center w-100" name="<?php echo e($type); ?><?php echo e($form_type); ?>_infant[]" value="0">
                    </div>
                    <div class="col-md-2 p-0">
                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-2" data-type="infant" data-inc="disabled" onClick="inc('<?php echo e($type); ?><?php echo e($form_type); ?>_infant[]', this)" disabled><i class="fi fi-plus smaller"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Work\ferry_frontend\resources\views/components/booking-search-form.blade.php ENDPATH**/ ?>