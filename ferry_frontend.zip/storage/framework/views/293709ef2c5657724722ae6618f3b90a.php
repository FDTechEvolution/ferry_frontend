<footer id="footer" class="text-dark">

    <!-- footer cta -->
    <div class="container text-dark pt-5 pb-2">

        <div class="row g-4 align-items-center">
            <div class="col-lg-12 d-lg-flex mb-0 justify-content-center">
                <img src="<?php echo e(asset('assets/images/SiriLanta_Speedboat.jpg')); ?>" class="px-2" width="" height="60">
                <img src="<?php echo e(asset('assets/images/aisasia.png')); ?>" class="px-2" width="" height="60">
                <img src="<?php echo e(asset('assets/images/nokair-logo.png')); ?>" class="px-2" width="" height="60">
                <img src="<?php echo e(asset('assets/images/cp-all-logo.png')); ?>" class="px-2" width="" height="60">
                <img src="<?php echo e(asset('assets/images/7-11_logo.png')); ?>" class="px-2" width="" height="60">
            </div>
            <div class="col-lg-12 text-center">
                <span class="text-warning">Terms & Conditions | Terms of Service | Privacy Policy ©2023 Tiger Line Ferry Company Limited. All Right Reserved.</span>
            </div>
        </div>

    </div>
    <!-- /footer cta -->

</footer><?php /**PATH D:\Work\ferry_frontend\resources\views/includes/footer.blade.php ENDPATH**/ ?>