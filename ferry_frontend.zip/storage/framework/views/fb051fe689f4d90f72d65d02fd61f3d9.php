<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 text-center mb-5">
        <h1 class="fw-bold">Time Table</h1>
    </div>

    <?php $__currentLoopData = $timetable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 text-center mb-4">
            <a class="fancybox" href="<?php echo e($img_url.'/'.$tt['image']['path']); ?>">
                <img src="<?php echo e($img_url.'/'.$tt['image']['path']); ?>" class="w-100 lazy">
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/timetable/index.blade.php ENDPATH**/ ?>