<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type' => '', 'station_from' => [], 'station_to' => []]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => '', 'station_from' => [], 'station_to' => []]); ?>
<?php foreach (array_filter((['type' => '', 'station_from' => [], 'station_to' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<form novalidate class="bs-validate" id="<?php echo e($type); ?>-search-form" method="POST" action="<?php echo e(route('booking-multi')); ?>">
    <?php echo csrf_field(); ?>
    <fieldset id="search-form">
        <input type="hidden" name="_type" value="<?php echo e($type); ?>">
        <?php if (isset($component)) { $__componentOriginal1fbeb59911dd3f0b9f9c563198a3250a = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.booking-search-form','data' => ['type' => $type,'stationFrom' => $station_from,'stationTo' => $station_to,'formType' => _('depart')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking-search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($type),'station_from' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($station_from),'station_to' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($station_to),'form_type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(_('depart'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fbeb59911dd3f0b9f9c563198a3250a)): ?>
<?php $component = $__componentOriginal1fbeb59911dd3f0b9f9c563198a3250a; ?>
<?php unset($__componentOriginal1fbeb59911dd3f0b9f9c563198a3250a); ?>
<?php endif; ?>
        <input type="hidden" class="from-0-input" name="from[]" value="">
        <input type="hidden" class="to-0-input" name="to[]" value="">
        <input type="hidden" class="date-0-input" name="date[]" value="">
        <div class="row multi-search-form-row">
            <div class="col-12 multi-search-form-0 d-none">
                <?php if (isset($component)) { $__componentOriginal194c002ef39ae8a184573c01cf21061f = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.booking-search-multi','data' => ['number' => 1]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking-search-multi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => 1]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal194c002ef39ae8a184573c01cf21061f)): ?>
<?php $component = $__componentOriginal194c002ef39ae8a184573c01cf21061f; ?>
<?php unset($__componentOriginal194c002ef39ae8a184573c01cf21061f); ?>
<?php endif; ?>
                <input type="checkbox" class="d-none multi-check-0" name="check_form[]" value="1">
            </div>
            <div class="col-12 multi-search-form-1 d-none">
                <?php if (isset($component)) { $__componentOriginal194c002ef39ae8a184573c01cf21061f = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.booking-search-multi','data' => ['number' => 2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking-search-multi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => 2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal194c002ef39ae8a184573c01cf21061f)): ?>
<?php $component = $__componentOriginal194c002ef39ae8a184573c01cf21061f; ?>
<?php unset($__componentOriginal194c002ef39ae8a184573c01cf21061f); ?>
<?php endif; ?>
                <input type="checkbox" class="d-none multi-check-1" name="check_form[]" value="1">
            </div>
            <div class="col-12 multi-search-form-2 d-none">
                <?php if (isset($component)) { $__componentOriginal194c002ef39ae8a184573c01cf21061f = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.booking-search-multi','data' => ['number' => 3]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking-search-multi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => 3]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal194c002ef39ae8a184573c01cf21061f)): ?>
<?php $component = $__componentOriginal194c002ef39ae8a184573c01cf21061f; ?>
<?php unset($__componentOriginal194c002ef39ae8a184573c01cf21061f); ?>
<?php endif; ?>
                <input type="checkbox" class="d-none multi-check-2" name="check_form[]" value="1">
            </div>
            <div class="col-12 multi-search-form-3 d-none">
                <?php if (isset($component)) { $__componentOriginal194c002ef39ae8a184573c01cf21061f = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.booking-search-multi','data' => ['number' => 4]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking-search-multi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['number' => 4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal194c002ef39ae8a184573c01cf21061f)): ?>
<?php $component = $__componentOriginal194c002ef39ae8a184573c01cf21061f; ?>
<?php unset($__componentOriginal194c002ef39ae8a184573c01cf21061f); ?>
<?php endif; ?>
                <input type="checkbox" class="d-none multi-check-3" name="check_form[]" value="1">
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-end">
                <i class="fi fi-plus cursor-pointer me-3" id="add-another-trip" data-bs-toggle="tooltip" data-bs-placement="left" title="Add another trip."></i>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-6 text-start">
                <a href="javascript:void(0);" class="text-light add-promotioncode-<?php echo e($type); ?> pt-2" onClick="addPromotionCode(this, '<?php echo e($type); ?>')"><i class="fa-solid fa-tag fs-4 me-1"></i> Add Promotioncode</a>
                <div class="div-promotioncode-<?php echo e($type); ?> position-relative w-50 d-none">
                    <input type="hidden" class="form-control form-control-sm input-promotioncode-<?php echo e($type); ?>" name="promotioncode">
                    <i class="fi fi-round-close text-dark cursor-pointer position-absolute top--9 end--9" onClick="clearPromotionCode('<?php echo e($type); ?>')"></i>
                </div>
            </div>
            <div class="col-6 text-end">
                <button type="submit" class="btn btn-sm button-orange-bg">Search</button>
            </div>
        </div>
    </fieldset>
</form>

<style>
    .datepicker::placeholder {
        color: #000 !important;
        opacity: 1;
    }
    .datepicker::-ms-input-placeholder {
        color: #000 !important;
    }
    .btn.btn-sm.rounded-circle {
        height: 1.5rem;
        width: 1.5rem;
    }
    i.fi.fi-minus.smaller, i.fi.fi-plus.smaller {
        font-size: 0.7rem !important;
    }
</style><?php /**PATH D:\Work\ferry_frontend\resources\views/components/booking-multi-ticket.blade.php ENDPATH**/ ?>