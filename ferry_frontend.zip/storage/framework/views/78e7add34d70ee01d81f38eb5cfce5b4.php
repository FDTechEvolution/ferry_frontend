<?php $__env->startSection('cover-content'); ?>
<div class="px-3 py-2 bg-primary lazy text-light">
    <div class="row">
        <div class="col-10 offset-1 d-flex align-items-center">
            <h4 class="my-2">Payment</h4>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 text-center d-none" id="back-to-home">
        <div class="d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-sm bg-main-color-2 text-light rounded"><i class="fi fi-home me-2"></i> Back To Home</a>
            <span class="mx-3">OR</span>
            <button class="btn btn-sm bg-main-color-2 text-light rounded" id="submit-booking-record"><i class="fa-regular fa-calendar-days me-2"></i> View Your Booking</button>
            <form action="<?php echo e(route('booking-record')); ?>" id="booking-record" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="booking_number" value="<?php echo e($_b); ?>">
            </form>
        </div>
    </div>
    <div class="col-12 text-center">
        <?php if(!empty($_p)): ?>
            <iframe name="output_frame" id="output_frame" src="<?php echo e($_p); ?>"  width="800" height="600"></iframe>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<style>
    @media (max-width: 540px) {
        iframe {
            aspect-ratio: 16 / 9;
            height: 60vh;
            width: 100%;
        }
    }
</style>
<script>
    const handlePaymentPostMessages = ({ data }) => {
        const { paymentResult } = data
        if (paymentResult) {
            const { respCode, respDesc, respData } = paymentResult
            const home = document.querySelector('#back-to-home')

            if(respCode == '2000'){
                home.classList.remove('d-none')
                // alert("payment completed")
                // window.location.replace("./payment/thankyou")
            }
        }
    }

    window.addEventListener('message', handlePaymentPostMessages)

    document.querySelector('#submit-booking-record').addEventListener('click', () => {
        document.querySelector('#booking-record').submit()
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/payment/index.blade.php ENDPATH**/ ?>