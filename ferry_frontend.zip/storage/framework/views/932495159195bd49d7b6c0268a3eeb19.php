<div id="booking-route-payment">
    <h4 class="mb-2">Litinerary</h4>
    <div class="row bg-booking-payment-litinerary mx-3 p-3 mb-5">
        <div class="col-12">
            <div class="row depart-litinerary">
                <div class="col-8 border-end border-secondary border-2" id="set-litinerary">
                    
                </div>
                <div class="col-4">
                    <?php $__currentLoopData = $route_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="set-passenger-litinerary mb-3 pb-3 border-bottom child-right">
                            <div class="row text-center fw-bold mb-2">
                                <div class="col-4 text-start">Depart</div>
                                <div class="col-4">Fare</div>
                                <div class="col-4">THB</div>
                            </div>
                            <?php if($passenger[0] != 0): ?>
                                <div class="row text-center">
                                    <div class="col-4 text-start">
                                        <?php if($passenger[0] > 1): ?> Adults <?php else: ?> Adult <?php endif; ?>
                                    </div>
                                    <div class="col-4"><?php echo e($passenger[0]); ?> x <span class="payment-adult-price-<?php echo e($index); ?>"></span></div>
                                    <div class="col-4"><span class="sum-of-adult-<?php echo e($index); ?>"></span></div>
                                </div>
                            <?php endif; ?>
                            <?php if($passenger[1] != 0): ?>
                                <div class="row text-center">
                                    <div class="col-4 text-start">
                                        <?php if($passenger[1] > 1): ?> Childs <?php else: ?> Child <?php endif; ?>
                                    </div>
                                    <div class="col-4"><?php echo e($passenger[1]); ?> x <span class="payment-child-price-<?php echo e($index); ?>"></span></div>
                                    <div class="col-4"><span class="sum-of-child-<?php echo e($index); ?>"></span></div>
                                </div>
                            <?php endif; ?>
                            <?php if($passenger[2] != 0): ?>
                                <div class="row text-center">
                                    <div class="col-4 text-start">
                                        <?php if($passenger[2] > 1): ?> Infants <?php else: ?> Infant <?php endif; ?>
                                    </div>
                                    <div class="col-4"><?php echo e($passenger[2]); ?> x <span class="payment-infant-price-<?php echo e($index); ?>"></span></div>
                                    <div class="col-4"><span class="sum-of-infant-<?php echo e($index); ?>"></span></div>
                                </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-12 text-end">
                                    <p class="fw-bold">Total : <span class="total-route-<?php echo e($index); ?> mb-0 mt-2 me-4 pe-1"></span></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-12 text-end pe-5 pt-3 border-top border-secondary">
                    <h6>Total THB <span class="sum-of-payment"></span></h6>
                </div>
            </div>
        </div>
    </div>

    <div id="payment-extra-service">
        <h4 class="mb-0">Extra services</h4>
        <div class="row bg-booking-payment-extra mx-3 p-3 mb-5">
            <div id="set-extra-service">
                
            </div>
            <div class="col-12 text-end mt-3 pt-3 border-top border-secondary">
                <h6 class="text-dark pe-4">Total THB <span id="sum-of-extra">0</span></h6>
            </div>
        </div>
    </div>

    <h4 class="mb-0">Passenger(s)</h4>
    <p class="mb-2">Passenger detail</p>
    <div class="row bg-booking-payment-passenger mx-3 p-4 mb-5">
        <div class="col-12">
            <div class="row" id="payment-passenger-detail">
                
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/booking/multi-island/booking-payment.blade.php ENDPATH**/ ?>