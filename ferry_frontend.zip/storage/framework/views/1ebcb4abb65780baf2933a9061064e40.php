<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['number' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['number' => '']); ?>
<?php foreach (array_filter((['number' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $from_id = uniqid();
    $to_id = uniqid();
    $date_id = uniqid();
    $passenger_id = uniqid();
    $action_id = uniqid();
?>

<div class="row px-3 is-type-multi">
    <input type="hidden" name="_from_type[]" value="multi">
    <div class="col-sm-3 col-md-3 px-0">
        <div class="form-floating mb-3">
            <select class="form-select form-select-sm from-<?php echo e($number); ?>-selected" id="from-<?php echo e($from_id); ?>" aria-label="booking station">
                <option value="" selected disabled>Select Original</option>
                
            </select>
            <label for="from-<?php echo e($from_id); ?>">From</label>
        </div>
        <input type="hidden" class="from-<?php echo e($number); ?>-input" name="from[]" value="">
    </div>
    <div class="col-sm-3 col-md-3 px-0">
        <div class="form-floating mb-3">
            <select class="form-select form-select-sm to-<?php echo e($number); ?>-selected" id="to-<?php echo e($to_id); ?>" aria-label="booking station" onChange="updateToDataValue(this, '<?php echo e($number); ?>')" disabled>
                <option value="" selected>Select Destination</option>
                
            </select>
            <label for="to-<?php echo e($to_id); ?>">To</label>
        </div>
        <input type="hidden" class="to-<?php echo e($number); ?>-input" name="to[]" value="">
    </div>
    <div class="col-sm-3 col-md-3 px-0">
        <div class="form-floating mb-3">
            <input type="text" class="form-control form-control-sm datepicker date-<?php echo e($number); ?>-selected"
                data-show-weeks="true"
                data-today-highlight="false"
                data-today-btn="true"
                data-clear-btn="false"
                data-autoclose="true"
                data-date-start="today"
                data-format="DD/MM/YYYY"
                autocomplete="off"
                placeholder="Travel Date"
                onChange="updateDateValue(this, '<?php echo e($number); ?>')">
            <label class="text-secondary">Travel Date</label>
        </div>
        <input type="hidden" class="date-<?php echo e($number); ?>-input" name="date[]" value="">
    </div>
    <div class="col-sm-3 col-md-3 px-3 d-flex justify-content-start align-items-center">
        <?php if($number < 4): ?>
            <div class="is-action" id="a-<?php echo e($action_id); ?>" style="margin-top: -16px;">
                <i class="fi fi-plus cursor-pointer me-3" data-bs-toggle="tooltip" data-bs-placement="left" title="Add another trip." onClick="addAmotherTrip('<?php echo e($action_id); ?>', '<?php echo e($number); ?>')"></i>
                <i class="fi fi-minus cursor-pointer me-3" data-bs-toggle="tooltip" data-bs-placement="left" title="Delete this trip." onClick="removeThisTrip('<?php echo e($action_id); ?>', '<?php echo e($number); ?>')"></i>
            </div>
        <?php elseif($number == 4): ?>
            <div class="is-action" id="a-<?php echo e($action_id); ?>" style="margin-top: -16px;">
                <i class="fi fi-minus cursor-pointer me-3" data-bs-toggle="tooltip" data-bs-placement="left" title="Delete this trip." onClick="removeThisTrip('<?php echo e($action_id); ?>', '<?php echo e($number); ?>')"></i>
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\Work\ferry_frontend\resources\views/components/booking-search-multi.blade.php ENDPATH**/ ?>