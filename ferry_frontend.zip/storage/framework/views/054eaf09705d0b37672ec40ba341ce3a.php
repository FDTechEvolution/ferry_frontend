<div id="booking-multi-route-extra">
    <h4 class="mb-0">Extra Service</h4>
    <span>Please selecte additional services</span>
    <?php $__currentLoopData = $route_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_index => $routes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mb-4">
        <div class="col-12 mb-2">
            <p class="mb-0 fw-bolder">
                <span class="me-0">Depart : </span>
                <span class="station-name me-4"><?php echo e($routes['station_from']); ?></span>
                <span class="me-0">Arrival : </span>
                <span class="station-name me-4"><?php echo e($routes['station_to']); ?></span>
                <span class="me-0">Date : </span>
                <span class="station-name"><?php echo e($routes['depart']); ?></span>
            </p>
        </div>
        <div class="col-11 ms-5 booking-route-extra border rounded p-3" data-list="<?php echo e($r_index); ?>">
            <?php $__currentLoopData = $routes['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['d-none' => empty($route['shuttle_bus'])]); ?>">
                    <div class="row route-shuttle-bus px-3 mb-3" id="route-shuttle-bus-index-<?php echo e($r_index); ?>_<?php echo e($index); ?>">
                        <?php if(!empty($route['shuttle_bus'])): ?>
                            <h5 class="mb-2">Shuttle bus</h5>
                            <?php $__currentLoopData = $route['shuttle_bus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 mb-3 pb-2 border-bottom">
                                <div class="row">
                                    <div class="col-1 d-flex justify-content-center align-items-center">
                                        <i class="fa-solid fa-van-shuttle fs-1"></i>
                                    </div>
                                    <div class="col-7">
                                        <h6 class="mb-1" id="extra-bus-name-<?php echo e($key); ?>_<?php echo e($r_index); ?>"><?php echo e($bus['name']); ?></h6>
                                        <p class="mb-0"><?php echo e($bus['description']); ?></p>
                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <span class="extra-bus-amount-<?php echo e($key); ?>_<?php echo e($r_index); ?> me-2"><?php echo e(number_format($bus['amount'])); ?></span> THB
                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="dec('bus', '<?php echo e($key); ?>', '<?php echo e($r_index); ?>')"><i class="fi fi-minus smaller"></i></button>
                                        <input type="number" name="bus_qty[<?php echo e($r_index); ?>][]" id="extra-bus-index-<?php echo e($key); ?>_<?php echo e($r_index); ?>" class="form-control form-control-xs text-center mx-2 border-0" value="0" readonly>
                                        <input type="hidden" name="bus_id[<?php echo e($r_index); ?>][]" value="<?php echo e($bus['id']); ?>">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="inc('bus', '<?php echo e($key); ?>', '<?php echo e($r_index); ?>')"><i class="fi fi-plus smaller"></i></button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['d-none' => empty($route['longtail_boat'])]); ?>">
                    <div class="row route-longtail-boat px-3 mb-3" id="route-longtail-boat-index-<?php echo e($r_index); ?>_<?php echo e($index); ?>">
                        <?php if(!empty($route['longtail_boat'])): ?>
                            <h5 class="mb-2">Longtail boat</h5>
                            <?php $__currentLoopData = $route['longtail_boat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $boat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 mb-3 pb-2 border-bottom">
                                <div class="row">
                                    <div class="col-1 d-flex justify-content-center align-items-center">
                                        <i class="fa-solid fa-sailboat fs-1"></i>
                                    </div>
                                    <div class="col-7">
                                        <h6 class="mb-1" id="extra-boat-name-<?php echo e($key); ?>_<?php echo e($r_index); ?>"><?php echo e($boat['name']); ?></h6>
                                        <p class="mb-0"><?php echo e($boat['description']); ?></p>
                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <span class="extra-boat-amount-<?php echo e($key); ?>_<?php echo e($r_index); ?> me-2"><?php echo e(number_format($boat['amount'])); ?></span> THB
                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="dec('boat', '<?php echo e($key); ?>', '<?php echo e($r_index); ?>')"><i class="fi fi-minus smaller"></i></button>
                                        <input type="number" name="boat_qty[<?php echo e($r_index); ?>][]" id="extra-boat-index-<?php echo e($key); ?>_<?php echo e($r_index); ?>" class="form-control form-control-xs text-center mx-2 border-0" value="0" readonly>
                                        <input type="hidden" name="boat_id[<?php echo e($r_index); ?>][]" value="<?php echo e($boat['id']); ?>">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="inc('boat', '<?php echo e($key); ?>', '<?php echo e($r_index); ?>')"><i class="fi fi-plus smaller"></i></button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['d-none' => empty($route['meal_lines'])]); ?>">
                    <div class="row route-meal px-3 mb-3" id="route-meal-index-<?php echo e($r_index); ?>_<?php echo e($index); ?>">
                        <?php if(!empty($route['meal_lines'])): ?>
                            <h5 class="mb-2">Meal Service</h5>
                            <?php $__currentLoopData = $route['meal_lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 mb-3 pb-2 border-bottom">
                                <div class="row">
                                    <div class="col-1 d-flex justify-content-center align-items-center">
                                        <img src="<?php echo e($icon_url); ?>/icon/meal/icon/<?php echo e($meal['image_icon']); ?>" width="80" id="extra-meal-img-<?php echo e($key); ?>_<?php echo e($r_index); ?>">
                                    </div>
                                    <div class="col-7">
                                        <h6 class="mb-1" id="extra-meal-name-<?php echo e($key); ?>_<?php echo e($r_index); ?>"><?php echo e($meal['name']); ?></h6>
                                        <p class="mb-0"><?php echo e($meal['description']); ?></p>
                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <span class="extra-meal-amount-<?php echo e($key); ?>_<?php echo e($r_index); ?> me-2"><?php echo e(number_format($meal['amount'])); ?></span> THB
                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="dec('meal', '<?php echo e($key); ?>', '<?php echo e($r_index); ?>')"><i class="fi fi-minus smaller"></i></button>
                                        <input type="number" name="meal_qty[<?php echo e($r_index); ?>][]" id="extra-meal-index-<?php echo e($key); ?>_<?php echo e($r_index); ?>" class="form-control form-control-xs text-center mx-2 border-0" value="0" readonly>
                                        <input type="hidden" name="meal_id[<?php echo e($r_index); ?>][]" value="<?php echo e($meal['id']); ?>">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="inc('meal', '<?php echo e($key); ?>', '<?php echo e($r_index); ?>')"><i class="fi fi-plus smaller"></i></button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['d-none' => empty($route['activity_lines'])]); ?>">
                    <div class="row route-activity px-3 mb-3" id="route-activity-index-<?php echo e($r_index); ?>_<?php echo e($index); ?>">
                        <?php if(!empty($route['activity_lines'])): ?>
                            <h5 class="mb-2">Activity Service</h5>
                            <?php $__currentLoopData = $route['activity_lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 mb-3 pb-2 border-bottom">
                                <div class="row">
                                    <div class="col-1 d-flex justify-content-center align-items-center">
                                        <img src="<?php echo e($icon_url); ?><?php echo e($activity['icon']['path'].'/'.$activity['icon']['name']); ?>" width="80" id="extra-activity-img-<?php echo e($key); ?>_<?php echo e($r_index); ?>">
                                    </div>
                                    <div class="col-7">
                                        <h6 class="mb-1" id="extra-activity-name-<?php echo e($key); ?>_<?php echo e($r_index); ?>"><?php echo e($activity['name']); ?></h6>
                                        <?php echo $activity['description']; ?>

                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <span class="extra-activity-amount-<?php echo e($key); ?>_<?php echo e($r_index); ?> me-2"><?php echo e(number_format($activity['amount'])); ?></span> THB
                                    </div>
                                    <div class="col-2 d-flex justify-content-center align-items-center">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="dec('activity', '<?php echo e($key); ?>')"><i class="fi fi-minus smaller"></i></button>
                                        <input type="number" name="activity_qty[<?php echo e($r_index); ?>][]" id="extra-activity-index-<?php echo e($key); ?>_<?php echo e($r_index); ?>" class="form-control form-control-xs text-center mx-2 border-0" value="0" readonly>
                                        <input type="hidden" name="activity_id[<?php echo e($r_index); ?>][]" value="<?php echo e($activity['id']); ?>">
                                        <button type="button" class="btn btn-primary rounded-circle btn-sm p-3" onClick="inc('activity', '<?php echo e($key); ?>')"><i class="fi fi-plus smaller"></i></button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH D:\Work\ferry_frontend\resources\views/pages/booking/multi-island/booking-extra.blade.php ENDPATH**/ ?>