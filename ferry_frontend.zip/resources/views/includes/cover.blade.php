<div class="section bg-theme-color-light overlay-dark overlay-opacity-8 bg-cover lazy" 
    data-background-image="demo.files/images/unsplash/realestate/ialicante-mediterranean-homes-vbSRUrNm3Ik-unsplash.jpg">
    
    <div class="container"> 
        <div class="row text-center-md text-center-xs d-middle justify-content-start">
            
            @yield('cover-content')
        </div>
    </div>

</div>	