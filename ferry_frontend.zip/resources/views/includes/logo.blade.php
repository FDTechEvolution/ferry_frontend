<a class="navbar-brand" href="{{ route('home') }}">
    <img src="{{ asset('tiger-line-ferry_logo.png') }}" alt="andamanexpress" style="margin-top: -10px;">
</a>